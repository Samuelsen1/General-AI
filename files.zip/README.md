# Image Generation API

A complete REST API for generating images with API key authentication and management.

## Features

- 🔑 **API Key Management** - Create, list, and revoke API keys
- 🎨 **Image Generation** - Generate images from text prompts
- 📊 **Usage Tracking** - Monitor API usage and statistics
- 🔒 **Secure Authentication** - SHA-256 hashed API keys
- 📈 **Rate Limiting Ready** - Built-in usage tracking

## Installation

1. Install dependencies:
```bash
pip install flask flask-cors pillow --break-system-packages
```

2. Run the server:
```bash
python image_api.py
```

The API will start on `http://localhost:5000`

## API Endpoints

### 1. Create API Key

**Endpoint:** `POST /v1/keys/create`

**Request:**
```bash
curl -X POST http://localhost:5000/v1/keys/create \
  -H "Content-Type: application/json" \
  -d '{"name": "My First Key"}'
```

**Response:**
```json
{
  "success": true,
  "api_key": "img_abc123def456...",
  "message": "API key created successfully. Save this key - it won't be shown again!",
  "key_info": {
    "id": 1,
    "name": "My First Key",
    "prefix": "img_abc123de...",
    "created_at": "2025-01-27T10:30:00"
  }
}
```

**⚠️ Important:** Save the `api_key` value immediately! It won't be displayed again.

### 2. Generate Image

**Endpoint:** `POST /v1/images/generate`

**Request:**
```bash
curl -X POST http://localhost:5000/v1/images/generate \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer img_abc123def456..." \
  -d '{
    "prompt": "A beautiful sunset over mountains",
    "width": 512,
    "height": 512
  }'
```

**Response:**
```json
{
  "success": true,
  "data": {
    "prompt": "A beautiful sunset over mountains",
    "width": 512,
    "height": 512,
    "image": "data:image/png;base64,iVBORw0KG...",
    "format": "png"
  }
}
```

**Parameters:**
- `prompt` (required): Text description of the image
- `width` (optional): Image width (256-1024, default: 512)
- `height` (optional): Image height (256-1024, default: 512)

### 3. List API Keys

**Endpoint:** `GET /v1/keys/list`

**Request:**
```bash
curl http://localhost:5000/v1/keys/list
```

**Response:**
```json
{
  "success": true,
  "keys": [
    {
      "id": 1,
      "prefix": "img_abc123de...",
      "name": "My First Key",
      "created_at": "2025-01-27T10:30:00",
      "last_used": "2025-01-27T11:45:00",
      "usage_count": 42,
      "active": true
    }
  ]
}
```

### 4. Revoke API Key

**Endpoint:** `POST /v1/keys/revoke/<key_id>`

**Request:**
```bash
curl -X POST http://localhost:5000/v1/keys/revoke/1
```

**Response:**
```json
{
  "success": true,
  "message": "API key revoked successfully"
}
```

### 5. Get Usage Statistics

**Endpoint:** `GET /v1/stats`

**Request:**
```bash
curl http://localhost:5000/v1/stats \
  -H "Authorization: Bearer img_abc123def456..."
```

**Response:**
```json
{
  "success": true,
  "stats": {
    "key_name": "My First Key",
    "created_at": "2025-01-27T10:30:00",
    "total_requests": 42,
    "total_generations": 42,
    "last_used": "2025-01-27T11:45:00"
  }
}
```

## Python Client Example

```python
import requests
import json

class ImageAPIClient:
    def __init__(self, api_key, base_url="http://localhost:5000"):
        self.api_key = api_key
        self.base_url = base_url
        self.headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {api_key}"
        }
    
    def generate_image(self, prompt, width=512, height=512):
        """Generate an image from a text prompt"""
        response = requests.post(
            f"{self.base_url}/v1/images/generate",
            headers=self.headers,
            json={"prompt": prompt, "width": width, "height": height}
        )
        return response.json()
    
    def get_stats(self):
        """Get usage statistics"""
        response = requests.get(
            f"{self.base_url}/v1/stats",
            headers=self.headers
        )
        return response.json()

# Usage
client = ImageAPIClient("img_your_api_key_here")
result = client.generate_image("A serene lake at dawn")
print(result)
```

## JavaScript Client Example

```javascript
class ImageAPIClient {
  constructor(apiKey, baseURL = 'http://localhost:5000') {
    this.apiKey = apiKey;
    this.baseURL = baseURL;
  }

  async generateImage(prompt, width = 512, height = 512) {
    const response = await fetch(`${this.baseURL}/v1/images/generate`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${this.apiKey}`
      },
      body: JSON.stringify({ prompt, width, height })
    });
    return await response.json();
  }

  async getStats() {
    const response = await fetch(`${this.baseURL}/v1/stats`, {
      headers: {
        'Authorization': `Bearer ${this.apiKey}`
      }
    });
    return await response.json();
  }
}

// Usage
const client = new ImageAPIClient('img_your_api_key_here');
client.generateImage('A futuristic city at night')
  .then(result => console.log(result));
```

## Security Best Practices

1. **Store API keys securely** - Never commit keys to version control
2. **Use environment variables** - Store keys in `.env` files
3. **Rotate keys regularly** - Create new keys and revoke old ones periodically
4. **Monitor usage** - Check statistics regularly for unusual activity
5. **Use HTTPS** - In production, always use HTTPS

## Database Schema

The API uses SQLite with two tables:

**api_keys:**
- `id` - Primary key
- `key_hash` - SHA-256 hash of the API key
- `key_prefix` - First 12 characters for display
- `name` - User-friendly name
- `created_at` - Creation timestamp
- `last_used` - Last usage timestamp
- `usage_count` - Total number of requests
- `active` - Whether the key is active

**generations:**
- `id` - Primary key
- `key_id` - Foreign key to api_keys
- `prompt` - The text prompt used
- `timestamp` - When the image was generated

## Error Codes

- `200` - Success
- `201` - Resource created
- `400` - Bad request (missing or invalid parameters)
- `401` - Unauthorized (invalid or missing API key)
- `404` - Not found
- `500` - Server error

## Future Enhancements

- [ ] Rate limiting per API key
- [ ] Multiple image format support (JPEG, WebP)
- [ ] Image style parameters (artistic, realistic, etc.)
- [ ] Batch generation endpoint
- [ ] Webhook notifications
- [ ] Advanced analytics dashboard
- [ ] Key expiration dates
- [ ] Usage quotas per key

## License

MIT License - feel free to use and modify as needed!
