from flask import Flask, request, jsonify, send_file
from flask_cors import CORS
import secrets
import hashlib
import sqlite3
import io
import base64
from datetime import datetime
from PIL import Image, ImageDraw, ImageFont
import random

app = Flask(__name__)
CORS(app)

# Database setup
def init_db():
    conn = sqlite3.connect('api_keys.db')
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS api_keys
                 (id INTEGER PRIMARY KEY AUTOINCREMENT,
                  key_hash TEXT UNIQUE NOT NULL,
                  key_prefix TEXT NOT NULL,
                  name TEXT,
                  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                  last_used TIMESTAMP,
                  usage_count INTEGER DEFAULT 0,
                  active INTEGER DEFAULT 1)''')
    
    c.execute('''CREATE TABLE IF NOT EXISTS generations
                 (id INTEGER PRIMARY KEY AUTOINCREMENT,
                  key_id INTEGER,
                  prompt TEXT,
                  timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                  FOREIGN KEY(key_id) REFERENCES api_keys(id))''')
    conn.commit()
    conn.close()

init_db()

def hash_key(key):
    return hashlib.sha256(key.encode()).hexdigest()

def generate_api_key():
    """Generate a new API key in the format: img_abc123def456..."""
    random_part = secrets.token_hex(20)
    return f"img_{random_part}"

def verify_api_key(api_key):
    """Verify API key and return key info if valid"""
    if not api_key or not api_key.startswith('img_'):
        return None
    
    key_hash_val = hash_key(api_key)
    conn = sqlite3.connect('api_keys.db')
    c = conn.cursor()
    c.execute('SELECT id, active FROM api_keys WHERE key_hash = ?', (key_hash_val,))
    result = c.fetchone()
    conn.close()
    
    if result and result[1] == 1:
        return result[0]
    return None

def update_key_usage(key_id):
    """Update last used timestamp and usage count"""
    conn = sqlite3.connect('api_keys.db')
    c = conn.cursor()
    c.execute('UPDATE api_keys SET last_used = ?, usage_count = usage_count + 1 WHERE id = ?',
              (datetime.now(), key_id))
    conn.commit()
    conn.close()

def generate_image(prompt, width=512, height=512):
    """Generate a placeholder image with the prompt text (simulate image generation)"""
    # Create a colorful gradient background
    img = Image.new('RGB', (width, height))
    draw = ImageDraw.Draw(img)
    
    # Generate random gradient colors based on prompt
    random.seed(hash(prompt))
    color1 = (random.randint(50, 200), random.randint(50, 200), random.randint(50, 200))
    color2 = (random.randint(50, 200), random.randint(50, 200), random.randint(50, 200))
    
    # Draw gradient
    for y in range(height):
        ratio = y / height
        r = int(color1[0] * (1 - ratio) + color2[0] * ratio)
        g = int(color1[1] * (1 - ratio) + color2[1] * ratio)
        b = int(color1[2] * (1 - ratio) + color2[2] * ratio)
        draw.rectangle([(0, y), (width, y + 1)], fill=(r, g, b))
    
    # Add prompt text
    try:
        font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 24)
    except:
        font = ImageFont.load_default()
    
    # Wrap text
    words = prompt.split()
    lines = []
    current_line = []
    for word in words:
        test_line = ' '.join(current_line + [word])
        bbox = draw.textbbox((0, 0), test_line, font=font)
        if bbox[2] - bbox[0] < width - 40:
            current_line.append(word)
        else:
            if current_line:
                lines.append(' '.join(current_line))
            current_line = [word]
    if current_line:
        lines.append(' '.join(current_line))
    
    # Draw text with shadow
    y_offset = (height - len(lines) * 30) // 2
    for i, line in enumerate(lines[:5]):  # Max 5 lines
        y = y_offset + i * 30
        # Shadow
        draw.text((22, y + 2), line, fill=(0, 0, 0), font=font)
        # Main text
        draw.text((20, y), line, fill=(255, 255, 255), font=font)
    
    return img

@app.route('/v1/keys/create', methods=['POST'])
def create_key():
    """Create a new API key"""
    data = request.json or {}
    name = data.get('name', 'Unnamed Key')
    
    api_key = generate_api_key()
    key_hash_val = hash_key(api_key)
    key_prefix = api_key[:12] + '...'
    
    conn = sqlite3.connect('api_keys.db')
    c = conn.cursor()
    try:
        c.execute('INSERT INTO api_keys (key_hash, key_prefix, name) VALUES (?, ?, ?)',
                  (key_hash_val, key_prefix, name))
        conn.commit()
        key_id = c.lastrowid
        conn.close()
        
        return jsonify({
            'success': True,
            'api_key': api_key,
            'message': 'API key created successfully. Save this key - it won\'t be shown again!',
            'key_info': {
                'id': key_id,
                'name': name,
                'prefix': key_prefix,
                'created_at': datetime.now().isoformat()
            }
        }), 201
    except sqlite3.IntegrityError:
        conn.close()
        return jsonify({'success': False, 'error': 'Key generation failed, please try again'}), 500

@app.route('/v1/keys/list', methods=['GET'])
def list_keys():
    """List all API keys (without exposing the actual keys)"""
    conn = sqlite3.connect('api_keys.db')
    c = conn.cursor()
    c.execute('''SELECT id, key_prefix, name, created_at, last_used, usage_count, active 
                 FROM api_keys ORDER BY created_at DESC''')
    keys = c.fetchall()
    conn.close()
    
    return jsonify({
        'success': True,
        'keys': [{
            'id': k[0],
            'prefix': k[1],
            'name': k[2],
            'created_at': k[3],
            'last_used': k[4],
            'usage_count': k[5],
            'active': bool(k[6])
        } for k in keys]
    })

@app.route('/v1/keys/revoke/<int:key_id>', methods=['POST'])
def revoke_key(key_id):
    """Revoke an API key"""
    conn = sqlite3.connect('api_keys.db')
    c = conn.cursor()
    c.execute('UPDATE api_keys SET active = 0 WHERE id = ?', (key_id,))
    conn.commit()
    affected = c.rowcount
    conn.close()
    
    if affected > 0:
        return jsonify({'success': True, 'message': 'API key revoked successfully'})
    return jsonify({'success': False, 'error': 'Key not found'}), 404

@app.route('/v1/images/generate', methods=['POST'])
def generate_image_endpoint():
    """Generate an image from a text prompt"""
    # Check API key
    api_key = request.headers.get('Authorization', '').replace('Bearer ', '')
    key_id = verify_api_key(api_key)
    
    if not key_id:
        return jsonify({'error': 'Invalid or missing API key'}), 401
    
    # Get parameters
    data = request.json
    if not data or 'prompt' not in data:
        return jsonify({'error': 'Missing required field: prompt'}), 400
    
    prompt = data['prompt']
    width = data.get('width', 512)
    height = data.get('height', 512)
    
    # Validate dimensions
    if width < 256 or width > 1024 or height < 256 or height > 1024:
        return jsonify({'error': 'Image dimensions must be between 256 and 1024 pixels'}), 400
    
    # Generate image
    img = generate_image(prompt, width, height)
    
    # Convert to base64
    img_buffer = io.BytesIO()
    img.save(img_buffer, format='PNG')
    img_buffer.seek(0)
    img_base64 = base64.b64encode(img_buffer.getvalue()).decode()
    
    # Update usage
    update_key_usage(key_id)
    
    # Log generation
    conn = sqlite3.connect('api_keys.db')
    c = conn.cursor()
    c.execute('INSERT INTO generations (key_id, prompt) VALUES (?, ?)', (key_id, prompt))
    conn.commit()
    conn.close()
    
    return jsonify({
        'success': True,
        'data': {
            'prompt': prompt,
            'width': width,
            'height': height,
            'image': f'data:image/png;base64,{img_base64}',
            'format': 'png'
        }
    })

@app.route('/v1/stats', methods=['GET'])
def get_stats():
    """Get usage statistics"""
    api_key = request.headers.get('Authorization', '').replace('Bearer ', '')
    key_id = verify_api_key(api_key)
    
    if not key_id:
        return jsonify({'error': 'Invalid or missing API key'}), 401
    
    conn = sqlite3.connect('api_keys.db')
    c = conn.cursor()
    c.execute('SELECT name, created_at, usage_count, last_used FROM api_keys WHERE id = ?', (key_id,))
    key_info = c.fetchone()
    
    c.execute('SELECT COUNT(*) FROM generations WHERE key_id = ?', (key_id,))
    total_generations = c.fetchone()[0]
    
    conn.close()
    
    return jsonify({
        'success': True,
        'stats': {
            'key_name': key_info[0],
            'created_at': key_info[1],
            'total_requests': key_info[2],
            'total_generations': total_generations,
            'last_used': key_info[3]
        }
    })

@app.route('/', methods=['GET'])
def index():
    """API information"""
    return jsonify({
        'name': 'Image Generation API',
        'version': '1.0.0',
        'endpoints': {
            'POST /v1/keys/create': 'Create a new API key',
            'GET /v1/keys/list': 'List all API keys',
            'POST /v1/keys/revoke/<id>': 'Revoke an API key',
            'POST /v1/images/generate': 'Generate an image (requires API key)',
            'GET /v1/stats': 'Get usage statistics (requires API key)'
        },
        'documentation': 'See README.md for usage examples'
    })

if __name__ == '__main__':
    print("\n" + "="*60)
    print("🎨 Image Generation API Server")
    print("="*60)
    print("\nServer starting on http://localhost:5000")
    print("\nQuick Start:")
    print("1. Create an API key: POST /v1/keys/create")
    print("2. Generate images: POST /v1/images/generate")
    print("\nView all endpoints: GET /")
    print("="*60 + "\n")
    app.run(debug=True, host='0.0.0.0', port=5000)
