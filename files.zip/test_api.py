#!/usr/bin/env python3
"""
Test script for the Image Generation API
Demonstrates creating keys and generating images
"""

import requests
import json
import time
import base64

BASE_URL = "http://localhost:5000"

def print_section(title):
    print("\n" + "="*60)
    print(f"  {title}")
    print("="*60 + "\n")

def create_api_key(name):
    """Create a new API key"""
    response = requests.post(
        f"{BASE_URL}/v1/keys/create",
        json={"name": name}
    )
    return response.json()

def list_keys():
    """List all API keys"""
    response = requests.get(f"{BASE_URL}/v1/keys/list")
    return response.json()

def generate_image(api_key, prompt, width=512, height=512):
    """Generate an image"""
    response = requests.post(
        f"{BASE_URL}/v1/images/generate",
        headers={
            "Content-Type": "application/json",
            "Authorization": f"Bearer {api_key}"
        },
        json={
            "prompt": prompt,
            "width": width,
            "height": height
        }
    )
    return response.json()

def get_stats(api_key):
    """Get usage statistics"""
    response = requests.get(
        f"{BASE_URL}/v1/stats",
        headers={"Authorization": f"Bearer {api_key}"}
    )
    return response.json()

def save_image(base64_data, filename):
    """Save base64 image to file"""
    # Remove the data:image/png;base64, prefix
    image_data = base64_data.split(',')[1]
    with open(filename, 'wb') as f:
        f.write(base64.b64decode(image_data))

def main():
    print("\n🎨 Image Generation API - Test Suite")
    
    # Test 1: Create API Key
    print_section("Test 1: Creating API Key")
    key_result = create_api_key("Test Key - Demo")
    
    if key_result.get('success'):
        api_key = key_result['api_key']
        print(f"✅ API Key Created Successfully!")
        print(f"   Key: {api_key}")
        print(f"   Name: {key_result['key_info']['name']}")
        print(f"   ID: {key_result['key_info']['id']}")
    else:
        print(f"❌ Failed to create API key: {key_result}")
        return
    
    # Test 2: List Keys
    print_section("Test 2: Listing All API Keys")
    keys_result = list_keys()
    
    if keys_result.get('success'):
        print(f"✅ Found {len(keys_result['keys'])} API key(s):")
        for key in keys_result['keys']:
            status = "🟢 Active" if key['active'] else "🔴 Revoked"
            print(f"\n   {status}")
            print(f"   ID: {key['id']}")
            print(f"   Name: {key['name']}")
            print(f"   Prefix: {key['prefix']}")
            print(f"   Usage: {key['usage_count']} requests")
    else:
        print(f"❌ Failed to list keys: {keys_result}")
    
    # Test 3: Generate Images
    print_section("Test 3: Generating Images")
    
    test_prompts = [
        "A beautiful sunset over mountains",
        "A futuristic city skyline",
        "Abstract geometric patterns"
    ]
    
    for i, prompt in enumerate(test_prompts, 1):
        print(f"Generating image {i}/3: '{prompt}'...")
        result = generate_image(api_key, prompt)
        
        if result.get('success'):
            print(f"✅ Image generated successfully!")
            print(f"   Size: {result['data']['width']}x{result['data']['height']}")
            
            # Save the image
            filename = f"/home/claude/generated_image_{i}.png"
            save_image(result['data']['image'], filename)
            print(f"   Saved to: {filename}")
        else:
            print(f"❌ Failed: {result}")
        
        time.sleep(0.5)  # Brief delay between requests
    
    # Test 4: Get Statistics
    print_section("Test 4: Usage Statistics")
    stats_result = get_stats(api_key)
    
    if stats_result.get('success'):
        stats = stats_result['stats']
        print(f"✅ Statistics Retrieved:")
        print(f"   Key Name: {stats['key_name']}")
        print(f"   Total Requests: {stats['total_requests']}")
        print(f"   Total Generations: {stats['total_generations']}")
        print(f"   Created: {stats['created_at']}")
        print(f"   Last Used: {stats['last_used']}")
    else:
        print(f"❌ Failed to get stats: {stats_result}")
    
    # Test 5: Invalid API Key
    print_section("Test 5: Testing Invalid API Key")
    result = generate_image("invalid_key_12345", "Test prompt")
    
    if 'error' in result:
        print(f"✅ Correctly rejected invalid key")
        print(f"   Error: {result['error']}")
    else:
        print(f"❌ Should have rejected invalid key!")
    
    # Summary
    print_section("Test Summary")
    print("All tests completed!")
    print(f"\n💡 Your API key: {api_key}")
    print("💡 Keep this key safe - you'll need it to generate images!")
    print("\n📝 Next steps:")
    print("   1. Use the API key in your applications")
    print("   2. Check the generated images in /home/claude/")
    print("   3. View the README.md for more examples")
    print("\n")

if __name__ == "__main__":
    try:
        # Check if server is running
        response = requests.get(BASE_URL, timeout=2)
        main()
    except requests.exceptions.ConnectionError:
        print("\n❌ Error: API server is not running!")
        print("Please start the server first:")
        print("   python image_api.py")
        print("\n")
    except Exception as e:
        print(f"\n❌ Error: {e}\n")
